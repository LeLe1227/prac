package com.apple.mapper;


import com.apple.po.Admin;
import com.apple.po.Student;

public interface AdminMapper {
 
	public Admin findAdminByUserName(String username) throws Exception;
	public Student findStudentByUserName(String studentNumber) throws Exception;
	public void changePassword(Admin admin) throws Exception;
	
	
	
}
